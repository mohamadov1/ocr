package com.ucf.tessrect.services;

import com.ucf.tessrect.model.MrzParser;
import com.ucf.tessrect.model.MrzRecord;
import net.sourceforge.tess4j.Tesseract1;
import net.sourceforge.tess4j.TesseractException;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ProcessingImage {
    private static final String REPLACEMENT_STRING = "<<<";
    private static final String INVALID_CHARS_PATTERN = "[^a-zA-Z0-9 <]";
    public static MrzRecord processImg(BufferedImage ipimage) throws IOException, TesseractException {
        Tesseract1 it = new Tesseract1();
        it.setDatapath("src/main/resources/tessdata");
        it.setLanguage("eng");
        String str = it.doOCR(ipimage);
        StringBuilder ocrResult = formatOcrResult(str);
        return MrzParser.parse(ocrResult.toString());
    }



    private static StringBuilder formatOcrResult(String str) {
        String[] lines = str.split("\n");
        List<String> mrzBuilder = new ArrayList<>();
        boolean pass = false;
        for (String line : lines) {
            line = line.replaceAll(" |~", "").replaceAll(INVALID_CHARS_PATTERN, "");
            if (line.startsWith("P<") || pass) {
                String lineOne = line.length() == 44 ? line : ajusterLongueur(line);
                mrzBuilder.add(lineOne);
                pass = true;
            }
        }

        if (mrzBuilder.size() < 2) {
            for (String line : lines) {
                line = line.replaceAll(" |~", "").replaceAll(INVALID_CHARS_PATTERN, "");
                if (line.startsWith("PK") || pass) {
                    String lineOne = ajusterLongueur(line.replace("PK", "P<"));
                    mrzBuilder.add(lineOne);
                    pass = true;
                }
            }
        }
        if (mrzBuilder.size() < 2) {
            for (String line : lines) {
                line = line.replaceAll(" |~", "").replaceAll(INVALID_CHARS_PATTERN, "");
                if (line.contains("P<") || pass) {
                    String lineOne = ajusterLongueur(removeTextBeforeKeyword(line));
                    mrzBuilder.add(lineOne);
                    pass = true;
                }
            }
        }
        if (mrzBuilder.size() < 2) {
            int lastTwoLines = lines.length - 2;
            for (int i = 0; i < lines.length; i++) {
                String line = lines[i].replaceAll(" |~", "").replaceAll(INVALID_CHARS_PATTERN, "");
                if ((i == lastTwoLines && (line.startsWith("P")) || pass)) {
                    String lineOne = ajusterLongueur(line.replace("P", "P<"));
                    mrzBuilder.add(lineOne);
                    pass = true;
                }
            }
        }

        if (mrzBuilder.size() < 2) {
            return new StringBuilder();
        }

        StringBuilder stringBuilder = new StringBuilder();
        String lineOne = cleanMRZ(mrzBuilder.get(0));
        String lineTwo = cleanMRZ(mrzBuilder.get(1));
        lineTwo = ajusterLongueur(lineTwo);
        stringBuilder.append(fixNameIssue(lineOne)).append("\n");
        stringBuilder.append(mrzBuilder.size() == 3 && lineTwo.length() < 10 ? cleanMRZ(mrzBuilder.get(2)) : lineTwo);
        System.out.println(stringBuilder);
        return stringBuilder;
    }


    private static StringBuilder formatOcrResult2(String str) {
        String[] lines = str.split("\n");
        boolean pass = false;
        List<String> mrzBuilder = new ArrayList<>();
        for (String line : lines) {
            line = line.replaceAll(" ", "").replaceAll("~", "").replaceAll("[^a-zA-Z0-9 <]", "");
            if (line.startsWith("P<") || pass) {
                String lineOne = line;
                if (lineOne.length() == 44) mrzBuilder.add(lineOne);
                else {
                    mrzBuilder.add(ajusterLongueur(lineOne));
                }
                pass = true;
            }
        }

        if (mrzBuilder.size() < 2) {
            for (String line : lines) {
                line = line.replaceAll(" ", "").replaceAll("~", "").replaceAll("[^a-zA-Z0-9 <]", "");
                if (line.startsWith("PK") || pass) {
                    String lineOne = line.replace("PK", "P<");
                    if (lineOne.length() == 44) mrzBuilder.add(lineOne);
                    else {
                        mrzBuilder.add(ajusterLongueur(lineOne));
                    }
                    pass = true;
                }
            }
        }
        if (mrzBuilder.size() < 2) {
            for (String line : lines) {
                line = line.replaceAll(" ", "").replaceAll("~", "").replaceAll("[^a-zA-Z0-9 <]", "");
                if (line.contains("P<") || pass) {
                    String lineOne = removeTextBeforeKeyword(line);
                    if (lineOne.length() == 44) mrzBuilder.add(lineOne);
                    else {
                        mrzBuilder.add(ajusterLongueur(lineOne));
                    }
                    pass = true;
                }
            }
        }
        if (mrzBuilder.size() < 2) {
            int ligne = 0;
            for (String line : lines) {
                line = line.replaceAll(" ", "").replaceAll("~", "").replaceAll("[^a-zA-Z0-9 <]", "");
                if (ligne == lines.length - 3 || ligne == lines.length - 2) {
                    if (line.startsWith("P") || pass) {
                        String lineOne = line.replace("P", "P<");
                        if (lineOne.length() == 44) mrzBuilder.add(lineOne);
                        else {
                            mrzBuilder.add(ajusterLongueur(lineOne));
                        }
                        pass = true;
                    }
                }
                ligne++;
            }
        }
        if (mrzBuilder.size() < 2) {
            return new StringBuilder();
        }
        StringBuilder stringBuilder = new StringBuilder();
        if (mrzBuilder.size() == 3) {
            if (mrzBuilder.get(1).length() < 10) {
                stringBuilder.append(fixNameIssue(cleanMRZ(mrzBuilder.get(0))));
                stringBuilder.append("\n");
                stringBuilder.append(cleanMRZ(mrzBuilder.get(2)));
            } else {
                stringBuilder.append(fixNameIssue(cleanMRZ(mrzBuilder.get(0))));
                stringBuilder.append("\n");
                stringBuilder.append(cleanMRZ(mrzBuilder.get(1)));
            }
        } else {
            stringBuilder.append(fixNameIssue(cleanMRZ(mrzBuilder.get(0))));
            stringBuilder.append("\n");
            stringBuilder.append(cleanMRZ(mrzBuilder.get(1)));
        }


        System.out.println(stringBuilder);
        return stringBuilder;
    }


    private static String cleanMRZ(String line) {
        String cleanText = replaceLowercaseChars(line);
        cleanText = cleanText.replaceAll("LLL", REPLACEMENT_STRING);
        cleanText = cleanText.replaceAll("LL<|<L<|<LL<", REPLACEMENT_STRING);
        cleanText = cleanText.replaceAll("<LL|<L<|LL<", REPLACEMENT_STRING);
        cleanText = cleanText.replaceAll("<KLL", "<<<<");
        cleanText = cleanText.replaceAll("<CLLK<", "<<<<<<");
        cleanText = cleanText.replace(   "<K<K<KLK", "");
        return clean(cleanText);
    }

    private static String fixNameIssue(String line){
        int index = line.indexOf("<<<");
        if (index != -1) {
            String newStr = line.substring(0, index + 1) + line.substring(index + 1).replaceAll(".","<");
            return newStr;
        }else {
            return line;
        }
    }

    private static String clean(String newStr) {
        return newStr.replaceAll("<<[A-Za-z]{1}<<", "<<<<<").replaceAll("<<[A-Za-z]{2}<<", "<<<<<<");
    }


    public static String removeTextBeforeKeyword(String input) {
        int index = input.indexOf("P<");
        if (index >= 0) {
            return input.substring(index);
        } else {
            return input;
        }
    }

    public static String replaceLowercaseChars(String inputString) {
        String outputString = "";
        for (int i = 0; i < inputString.length(); i++) {
            char c = inputString.charAt(i);
            if (Character.isLowerCase(c)) {
                outputString += "<";
            } else {
                outputString += c;
            }
        }
        return outputString;
    }

    public static String ajusterLongueur(String chaine) {
        int longueurMax = 44;
        int longueurActuelle = chaine.length();
        if (longueurActuelle > longueurMax) {
            chaine = chaine.substring(0, longueurMax);
        } else {
            int difference = longueurMax - longueurActuelle;
            StringBuilder chaineBuilder = new StringBuilder(chaine);
            for (int i = 0; i < difference; i++) {
                chaineBuilder.append("<");
            }
            chaine = chaineBuilder.toString();
        }
        return chaine;
    }


    public static File convertToBlackAndWhite(File file, String newFileName) {
        try {
            final BufferedImage colorImage = ImageIO.read(file);
            Graphics2D g = colorImage.createGraphics();
            g.drawImage(colorImage, null, 0, 0);
            final BufferedImage grayImage = new BufferedImage(colorImage.getWidth(), colorImage.getHeight(), BufferedImage.TYPE_BYTE_GRAY);
            g = grayImage.createGraphics();
            g.drawImage(colorImage, 0, 0, null);
            g.dispose();
            File output = new File("src/main/resources/tessdata" + newFileName + ".png");
            ImageIO.write(grayImage, "png", output);
            return output;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }


}
